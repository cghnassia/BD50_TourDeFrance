﻿REM INSERTING into G11_FLIGHT.PAYS
SET DEFINE OFF;
Insert into G11_FLIGHT.CATEGORIE (CAT_NUM,CAT_LIB,MAILLOT_COULEUR) values ('1','Col de categorie 4','pois');
Insert into G11_FLIGHT.CATEGORIE (CAT_NUM,CAT_LIB,MAILLOT_COULEUR) values ('2','Col de categorie 3','pois');
Insert into G11_FLIGHT.CATEGORIE (CAT_NUM,CAT_LIB,MAILLOT_COULEUR) values ('3','Col de categorie 2','pois');
Insert into G11_FLIGHT.CATEGORIE (CAT_NUM,CAT_LIB,MAILLOT_COULEUR) values ('4','Col de categorie 1','pois');
Insert into G11_FLIGHT.CATEGORIE (CAT_NUM,CAT_LIB,MAILLOT_COULEUR) values ('5','Col hors categorie','pois');
Insert into G11_FLIGHT.CATEGORIE (CAT_NUM,CAT_LIB,MAILLOT_COULEUR) values ('6','Sprint intermediaire','vert');
Insert into G11_FLIGHT.CATEGORIE (CAT_NUM,CAT_LIB,MAILLOT_COULEUR) values ('7','Sprint final','vert');
