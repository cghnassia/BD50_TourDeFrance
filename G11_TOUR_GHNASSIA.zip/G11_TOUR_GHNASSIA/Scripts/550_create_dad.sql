BEGIN DBMS_EPG.create_dad
(
dad_name =>'g11_tour_epg_dad',
path => '/g11_tour_epg_dad/*');
END;
/ 