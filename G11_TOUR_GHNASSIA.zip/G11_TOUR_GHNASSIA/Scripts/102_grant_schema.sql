Grant connect, resource , plustrace
, create view, create synonym, create user, alter user
, xdbadmin
to G11_FLIGHT with admin option ;
grant execute on dbms_epg to G11_FLIGHT with grant option ;
