connect G11_FLIGHT/G11_FLIGHT
set define off

Start 200_create_table.sql
Start 205_create_table_partitionnement.sql
Start 210_create_pk.sql
Start 215_create_table_iot.sql
Start 220_create_fk.sql
Start 230_create_check.sql
Start 240_create_sequence.sql
Start 260_verify_structure.sql
