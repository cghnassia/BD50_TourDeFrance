--------------------------------------------------------
--  DDL for Package UI_PARAM_COMMUN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "G11_FLIGHT"."UI_PARAM_COMMUN" AS 

  path_img varchar2(255) := '/public/img/';
  path_css varchar2(255) := '/public/css/';
  

END UI_PARAM_COMMUN;

/