DROP SEQUENCE seq_cycliste ;
DROP SEQUENCE seq_pays ;
DROP SEQUENCE seq_dirs ;
DROP SEQUENCE seq_ville ;
DROP SEQUENCE seq_categorie ;
DROP SEQUENCE seq_utilisateur ;
DROP SEQUENCE seq_controle ;
DROP SEQUENCE seq_specialiste ;