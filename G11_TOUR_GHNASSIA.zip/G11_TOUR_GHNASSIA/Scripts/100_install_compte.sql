connect SYSTEM/manager
set define off

Start 101_create_schema.sql
Start 102_grant_schema.sql
Start 103_connect_schema.sql
